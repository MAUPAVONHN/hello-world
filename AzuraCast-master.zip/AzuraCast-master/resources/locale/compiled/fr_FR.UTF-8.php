<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: Buster "Silver Eagle" Neece (SlvrEagle23)
Language-Team: French
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2019-09-10T23:21:55+00:00
PO-Revision-Date: 2019-10-08 07:42
Language: fr_FR
Plural-Forms: nplurals=2; plural=(n > 1);
X-Generator: crowdin.com
X-Crowdin-Project: azuracast
X-Crowdin-Language: fr
X-Crowdin-File: /master/resources/locale/default.pot
',
      ),
      'All Permissions' => 
      array (
        0 => 'Toutes les permissions',
      ),
      'View Administration Page' => 
      array (
        0 => 'Voir la page d\'administration',
      ),
      'View System Logs' => 
      array (
        0 => 'Voir les journaux système',
      ),
      'Administer Settings' => 
      array (
        0 => 'Paramètres d\'administration',
      ),
      'Administer API Keys' => 
      array (
        0 => 'Administrer les clés API',
      ),
      'Administer Users' => 
      array (
        0 => 'Administrer les utilisateurs',
      ),
      'Administer Permissions' => 
      array (
        0 => 'Administrer les autorisations',
      ),
      'Administer Stations' => 
      array (
        0 => 'Administrer les stations',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Administrer les champs personnalisés',
      ),
      'Administer Backups' => 
      array (
        0 => 'Administrer les sauvegardes',
      ),
      'View Station Page' => 
      array (
        0 => 'Voir la page de la station',
      ),
      'View Station Reports' => 
      array (
        0 => 'Voir les rapports de la station',
      ),
      'View Station Logs' => 
      array (
        0 => 'Voir les journaux de la station',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Gérer les profils des stations',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Gérer la diffusion de la station',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Gérer les Streamers de station',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Gérer les points de montage des stations',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Gérer les relais à distance de la station',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Gérer les fichiers musicaux de la station',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Gérer l\'automatisation de la station',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Gérer les Web Hooks de la station',
      ),
      'AzuraCast Backup' => 
      array (
        0 => 'Sauvegarde d\'AzuraCast',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => 'Veuillez patienter pendant qu\'une sauvegarde est générée...',
      ),
      'Creating temporary directories...' => 
      array (
        0 => 'Création de répertoires temporaires...',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => 'Dossier "%s" n\'a pas été créé',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => 'Sauvegarde de MariaDB...',
      ),
      'Backing up InfluxDB...' => 
      array (
        0 => 'Sauvegarde d\'InfluxDB...',
      ),
      'Creating backup archive...' => 
      array (
        0 => 'Création d\'une archive de sauvegarde...',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => 'Nettoyage des fichiers temporaires...',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => 'Sauvegarde complétée en %.2f secondes.',
      ),
      'AzuraCast Settings' => 
      array (
        0 => 'Paramètres d\'AzuraCast',
      ),
      'Setting Key' => 
      array (
        0 => 'Clé de réglage',
      ),
      'Setting Value' => 
      array (
        0 => 'Réglage de la valeur',
      ),
      'Locales generated.' => 
      array (
        0 => 'Localisation générée.',
      ),
      'Imported locale: %s' => 
      array (
        0 => 'Localisation importée : %s',
      ),
      'Locales imported.' => 
      array (
        0 => 'Localisation importées.',
      ),
      'Configuration already set up.' => 
      array (
        0 => 'La configuration est déjà effectuée.',
      ),
      'Configuration successfully written.' => 
      array (
        0 => 'La configuration a été correctement enregistrée.',
      ),
      'Backup path %s not found!' => 
      array (
        0 => 'Chemin de sauvegarde %s non trouvé !',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => 'Le compte associé à l\'adresse e-mail "%s" a été défini en tant qu\'administrateur',
      ),
      'Account not found.' => 
      array (
        0 => 'Compte non trouvé.',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'Installation d\'AzuraCast',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'Bienvenue sur AzuraCast. Veuillez patienter pendant que quelques dépendances clés d\'AzuraCast sont mises en place...',
      ),
      'Environment: %s' => 
      array (
        0 => 'Environnement : %s',
      ),
      'Installation Method: %s' => 
      array (
        0 => 'Méthode d\'installation : %s',
      ),
      'Running in update mode.' => 
      array (
        0 => 'Exécution en mode mise à jour.',
      ),
      'Migrating Legacy Configuration' => 
      array (
        0 => 'Migration de l\'ancienne configuration',
      ),
      'Setting Up InfluxDB' => 
      array (
        0 => 'Configuration d\'InfluxDB',
      ),
      'Running Database Migrations' => 
      array (
        0 => 'Exécution des migrations de bases de données',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => 'Génération des classes proxy de base de données',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => 'Installation des fixations de données',
      ),
      'Refreshing All Stations' => 
      array (
        0 => 'Actualisation de toutes les stations',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => 'AzuraCast est maintenant mis à jour vers la dernière version !',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => 'L\'installation d\'AzuraCast est terminée !',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => 'Visitez %s pour compléter l\'installation.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => 'Fixations chargées.',
      ),
      'Database created.' => 
      array (
        0 => 'Base de données créée.',
      ),
      'Retention policies updated.' => 
      array (
        0 => 'Mise à jour des politiques de confidentialité.',
      ),
      'Continuous queries created.' => 
      array (
        0 => 'Requêtes continues créées.',
      ),
      'InfluxDB databases created.' => 
      array (
        0 => 'Bases de données InfluxDB créées.',
      ),
      'Record not found.' => 
      array (
        0 => 'Enregistrement non trouvé.',
      ),
      'API Key updated.' => 
      array (
        0 => 'Clé API mise à jour.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Éditer la clé API',
      ),
      'API Key deleted.' => 
      array (
        0 => 'Clé API supprimée.',
      ),
      'Changes saved.' => 
      array (
        0 => 'Modifications enregistrées.',
      ),
      'Configure Backups' => 
      array (
        0 => 'Configurer les sauvegardes',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Exécuter la sauvegarde manuelle',
      ),
      'Backup not found.' => 
      array (
        0 => 'Sauvegarde non trouvée.',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Sauvegarde supprimée.',
      ),
      'Custom Field updated.' => 
      array (
        0 => 'Champ personnalisé mis à jour.',
      ),
      'Custom Field added.' => 
      array (
        0 => 'Champ personnalisé ajouté.',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Modifier un champ personnalisé',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Ajouter un champ personnalisé',
      ),
      'Custom Field deleted.' => 
      array (
        0 => 'Champ personnalisé supprimé.',
      ),
      'Sync Task Output' => 
      array (
        0 => 'Synchronisation de sortie de tâche',
      ),
      'SHOUTcast version "%s" is currently installed.' => 
      array (
        0 => 'La version de SHOUTcast "%s" est actuellement installé.',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Installer SHOUTcast',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'Logs de l\'application AzuraCast',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Logs d’accès Nginx',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Logs d\'erreurs Nginx',
      ),
      'PHP Application Log' => 
      array (
        0 => 'Log de l\'application PHP',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Log de Supervisord',
      ),
      'Permission updated.' => 
      array (
        0 => 'Permission mise à jour.',
      ),
      'Permission added.' => 
      array (
        0 => 'Permission ajoutée.',
      ),
      'Edit Permission' => 
      array (
        0 => 'Modifier l\'autorisation',
      ),
      'Add Permission' => 
      array (
        0 => 'Ajouter une permission',
      ),
      'Permission deleted.' => 
      array (
        0 => 'Permission supprimée.',
      ),
      'System Settings' => 
      array (
        0 => 'Configuration système',
      ),
      'Station updated.' => 
      array (
        0 => 'Station mise à jour.',
      ),
      'Station added.' => 
      array (
        0 => 'Station ajoutée.',
      ),
      'Edit Station' => 
      array (
        0 => 'Modifier la station',
      ),
      'Station deleted.' => 
      array (
        0 => 'Station supprimée.',
      ),
      'Station not found.' => 
      array (
        0 => 'Station introuvable.',
      ),
      'Clone Station: %s' => 
      array (
        0 => 'Clone de la station : %s',
      ),
      'User updated.' => 
      array (
        0 => 'Utilisateur mis à jour.',
      ),
      'User added.' => 
      array (
        0 => 'Utilisateur ajouté.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Il existe déjà un autre utilisateur avec cette adresse E-mail. Veuillez modifier votre adresse E-mail.',
      ),
      'Edit User' => 
      array (
        0 => 'Modifier l\'utilisateur',
      ),
      'Add User' => 
      array (
        0 => 'Ajouter un utilisateur',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Vous ne pouvez pas supprimer votre propre compte.',
      ),
      'User deleted.' => 
      array (
        0 => 'Utilisateur supprimé.',
      ),
      'User not found.' => 
      array (
        0 => 'Utilisateur non trouvé.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Connecté avec succès.',
      ),
      'Record not found!' => 
      array (
        0 => 'Enregistrement non trouvé !',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Modifications enregistrées avec succès.',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'L\'enregistrement a été supprimé avec succès.',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Vous ne pouvez vous supprimer vous-même.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Cette station n\'accepte pas de demandes pour le moment.',
      ),
      'Request submitted successfully.' => 
      array (
        0 => 'Demande envoyée avec succès.',
      ),
      'Station restarted.' => 
      array (
        0 => 'Redémarrage de la station.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Frontend s\'est arrêté.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Frontend a démarré.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Frontend redémarre.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Le titre à été passé.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer déconnecté.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Backend s\'arrête.',
      ),
      'Backend started.' => 
      array (
        0 => 'Backend démarre.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Backend redémarre.',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Trop de tentatives de connexion',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Tentatives de connexion trop nombreuses. Veuillez essayer de nouveau dans 30 secondes.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Échec de connexion',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Vos informations d\'identification n\'ont pas pu être vérifiées.',
      ),
      'API Key not found.' => 
      array (
        0 => 'Clé API introuvable.',
      ),
      'Add API Key' => 
      array (
        0 => 'Ajouter une clé API',
      ),
      'All Stations' => 
      array (
        0 => 'Toutes les stations',
      ),
      'Listeners' => 
      array (
        0 => 'Auditeurs',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profil enregistré !',
      ),
      'Edit Profile' => 
      array (
        0 => 'Modifier le profil',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Le jeton que vous avez fourni n\'est pas valide. Veuillez réessayer.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Authentification à deux facteurs activée.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Authentification à deux facteurs désactivée.',
      ),
      'Song Title' => 
      array (
        0 => 'Titre de la musique',
      ),
      'Song Artist' => 
      array (
        0 => 'Artiste de la musique',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'L\'installation est déjà terminée !',
      ),
      'Super Administrator' => 
      array (
        0 => 'Super administrateur',
      ),
      'Setup is now complete!' => 
      array (
        0 => 'L\'installation s\'est terminée !',
      ),
      'Continue setting up your station in the main AzuraCast app.' => 
      array (
        0 => 'Poursuivez la configuration de votre station dans l’application principale d\'AzuraCast.',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Affectation automatique complété !',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Erreur lors de l\'affectation automatique',
      ),
      'Path "%s" is not a folder.' => 
      array (
        0 => 'Le chemin "%s" n\'est pas un dossier.',
      ),
      'Could not move "%s" to "%s"' => 
      array (
        0 => 'Impossible de déplacer "%s" vers "%s"',
      ),
      'Media not found.' => 
      array (
        0 => 'Médias non trouvés.',
      ),
      'Media updated.' => 
      array (
        0 => 'Média mis à jour.',
      ),
      'Edit Media' => 
      array (
        0 => 'Modifier le média',
      ),
      'File renamed!' => 
      array (
        0 => 'Fichier renommé !',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Renommer le fichier/répertoire',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Cette station n\'a plus d\'espace de stockage disponible.',
      ),
      'Directory' => 
      array (
        0 => 'Annuaire',
      ),
      'File Not Processed' => 
      array (
        0 => 'Fichier non traité',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Cette fonctionnalité n\'est pas compatible avec cette station.',
      ),
      'Edit Mount Point' => 
      array (
        0 => 'Modifier le point de montage',
      ),
      'Add Mount Point' => 
      array (
        0 => 'Ajouter un point de montage',
      ),
      'Mount Point deleted.' => 
      array (
        0 => 'Point de montage supprimé.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'La playlist n\'a pas été trouvée.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Cette playlist n’est pas une playlist séquentielle.',
      ),
      'Format not found.' => 
      array (
        0 => 'Format non trouvé.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Playlist activé.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Playlist désactivée.',
      ),
      'Playlist updated.' => 
      array (
        0 => 'Playlist mise à jour.',
      ),
      'Playlist added.' => 
      array (
        0 => 'Playlist ajoutée.',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Modifier la playlist',
      ),
      'Add Playlist' => 
      array (
        0 => 'Ajouter une playlist',
      ),
      'Playlist deleted.' => 
      array (
        0 => 'Playlist supprimée.',
      ),
      'Remote Relay updated.' => 
      array (
        0 => 'Relais à distance mis à jour.',
      ),
      'Remote Relay added.' => 
      array (
        0 => 'Relais à distance ajouté.',
      ),
      'Edit Remote Relay' => 
      array (
        0 => 'Modifier le relais à distance',
      ),
      'Add Remote Relay' => 
      array (
        0 => 'Ajouter un relais à distance',
      ),
      'Remote Relay deleted.' => 
      array (
        0 => 'Relais à distance supprimé.',
      ),
      'This record cannot be edited.' => 
      array (
        0 => 'Cet enregistrement ne peut pas être modifié.',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Auditeurs par jour',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Auditeurs par jour de la semaine',
      ),
      'Monday' => 
      array (
        0 => 'Lundi',
      ),
      'Tuesday' => 
      array (
        0 => 'Mardi',
      ),
      'Wednesday' => 
      array (
        0 => 'Mercredi',
      ),
      'Thursday' => 
      array (
        0 => 'Jeudi',
      ),
      'Friday' => 
      array (
        0 => 'Vendredi',
      ),
      'Saturday' => 
      array (
        0 => 'Samedi',
      ),
      'Sunday' => 
      array (
        0 => 'Dimanche',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Auditeurs par heure',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'Rapport SoundExchange',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streamers activés !',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Vous pouvez maintenant configurer des comptes pour les streamers (DJs).',
      ),
      'Streamer updated.' => 
      array (
        0 => 'Streamer mis à jour.',
      ),
      'Streamer added.' => 
      array (
        0 => 'Streamer ajouté.',
      ),
      'Edit Streamer' => 
      array (
        0 => 'Modifier le Streamer',
      ),
      'Add Streamer' => 
      array (
        0 => 'Ajouter Streamer',
      ),
      'Streamer deleted.' => 
      array (
        0 => 'Streamer supprimé.',
      ),
      'Web Hook added.' => 
      array (
        0 => 'Web Hook ajouté.',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Ajouter un Web Hook',
      ),
      'Web Hook updated.' => 
      array (
        0 => 'Web Hook mis à jour.',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Modifier Web Hook',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Web Hook activé.',
      ),
      'Web Hook disabled.' => 
      array (
        0 => 'Web Hook désactivé.',
      ),
      'Web Hook Test Output' => 
      array (
        0 => 'Tester la Web Hook',
      ),
      'Web Hook deleted.' => 
      array (
        0 => 'Web Hook supprimé.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Log de Liquidsoap',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Configuration de liquidsoap',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Logs d’accès Icecast',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Logs d\'erreur icecast',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Configuration d’Icecast',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'Logs de SHOUTcast',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'Configuration de SHOUTcast',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Les robots des moteurs de recherche ne sont pas autorisés à utiliser cette fonctionnalité.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'L\'ID du morceau que vous avez spécifié n\'a pas été trouvé dans la station.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'L\'ID du morceau que vous avez spécifié ne peut pas être demandé pour cette station.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'Vous avez fait une demande trop récemment ! Veuillez patienter avant d\'en soumettre un autre.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Requête en double : cette chanson a déjà été demandée et sera jouée bientôt.',
      ),
      'This song was already played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Cette chanson a déjà été jouée récemment. Attendez un peu avant de la demander à nouveau.',
      ),
      'Select File' => 
      array (
        0 => 'Sélectionner un fichier',
      ),
      'Want to use SHOUTcast 2? <a href="%s" target="_blank">Install it here</a>, then reload this page.' => 
      array (
        0 => 'Vous souhaitez utiliser SHOUTcast 2 ? <a href="%s" target="_blank">Installez-le ici</a>, ensuite recharger la page.',
      ),
      'This station\'s time zone is currently %s.' => 
      array (
        0 => 'Le fuseau horaire de cette station est actuellement %s.',
      ),
      'The current time in the station\'s time zone is %s.' => 
      array (
        0 => 'Pour le fuseau horaire de la station, l\'heure actuelle est %s.',
      ),
      'Existing playlist imported.' => 
      array (
        0 => 'Playlist existante importée.',
      ),
      '%d song(s) were imported into the playlist.' => 
      array (
        0 => '%d titres(s) ont été importés dans la playlist.',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Vous devez être connecté pour accéder à cette page.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'Vous n’êtes pas autorisé à accéder à cette partie du site.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Votre fichier <code>docker-compose.yml</code> est obsolète!',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes. View the <a href="%s" target="_blank">latest version of the file</a> and update your file accordingly.<br>You can also use the <code>./docker.sh</code> utility script to automatically update your file.' => 
      array (
        0 => 'Vous devriez mettre à jour votre <code>docker-compose.yml</code> pour afficher les changements les plus récents. Voir la <a href="%s" target="_blank"> version la plus récente du fichier </a> et mettez à jour votre fichier en conséquence.<br>Vous pouvez également utiliser la commande <code>./docker.sh</code> pour mettre à jour automatiquement votre fichier.',
      ),
      'Follow the <a href="%s" target="_blank">update instructions</a> to update your installation.' => 
      array (
        0 => 'Suivez les <a href="%s" target="_blank"> instructions de mise à jour </a> pour mettre à jour votre installation.',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'AzuraCast <a href="%s" target="_blank">version %s</a> est maintenant disponible.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'Vous exécutez actuellement la version %s. La mise à jour est fortement recommandée.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Une nouvelle version d\'AzuraCast est disponible',
      ),
      'The following improvements have been made since your last update:' => 
      array (
        0 => 'Les améliorations suivantes ont été apportées depuis la dernière mise à jour :',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Votre installation est actuellement %d mise à jour derrière la dernière version.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Vous devriez mettre à jour pour profiter des corrections de bugs et de sécurité.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Nouvelles mises à jour d\'AzuraCast disponibles',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s n\'est pas reconnu comme un service.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Il se peut qu\'il ne soit pas encore enregistré auprès du superviseur. Le redémarrage de la diffusion peut aider.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s ne peut pas démarrer',
      ),
      'It is already running.' => 
      array (
        0 => 'Il est déjà en cours d\'exécution.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s ne peut s\'arrêter',
      ),
      'It is not running.' => 
      array (
        0 => 'Il ne fonctionne pas.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s a rencontré une erreur',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Consultez le fichier log pour plus de détails.',
      ),
      'Use <b>%s</b> on this server' => 
      array (
        0 => 'Utilisez <b>%s</b> sur ce serveur',
      ),
      'Connect to a <b>remote radio server</b>' => 
      array (
        0 => 'Connectez-vous à un <b>serveur radio distant</b>',
      ),
      '<b>Do not use</b> an AutoDJ service' => 
      array (
        0 => '<b>Ne pas utiliser</b> un service AutoDJ',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Données du titre en cours',
      ),
      '1-Minute Sync' => 
      array (
        0 => 'Synchro chaque minute',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'File d\'attente de la demande de titres',
      ),
      '5-Minute Sync' => 
      array (
        0 => 'Synchro chaque 5 minutes',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Vérification des dossiers Media',
      ),
      '1-Hour Sync' => 
      array (
        0 => 'Synchro chaque heure',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Performances/Statistiques',
      ),
      'Cleanup' => 
      array (
        0 => 'Nettoyage',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'Le port %s est actuellement utilisé par une autre station.',
      ),
      'Password cannot contain the following characters: %s' => 
      array (
        0 => 'Le mot de passe ne peut contenir les caractères suivants : %s',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => 'Générer le fichier local de traduction.',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => 'Convertissez les fichiers de langue traduits en tableaux PHP.',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => 'Migration de la configuration existante vers le nouveau format INI si celui-ci existe.',
      ),
      'Initial setup of InfluxDB.' => 
      array (
        0 => 'Première installation de InfluxDB.',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => 'Installez des fixations pour la démo / développement local.',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => 'Réaliser toutes les étapes générales d\'installation d\'AzuraCast.',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => 'Exécutez une ou plusieurs tâches de synchronisation planifiées.',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Procédez au traitement de la file d\'attente des messages.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'Lister tous les paramètres dans la base de données des paramètres AzuraCast.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'Sauvegardez la base de données et les statistiques d\'AzuraCast (Et éventuellement les fichiers musicaux).',
      ),
      'Comments' => 
      array (
        0 => 'Commentaires',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Décrire le cas d\'utilisation de cette clé API pour référence ultérieure.',
      ),
      'Save Changes' => 
      array (
        0 => 'Sauvegarder',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Activer l’affectation automatique',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Laissez le système affecter automatiquement et périodiquement les titres a des playlists, basées sur leurs performances. Ce processus s’exécute en arrière-plan et ne fonctionnera que si cette option est définie sur « Activé » et au moins une liste de lecture est définie à « Inclure dans l’Affectation Automatique ».',
      ),
      'Disabled' => 
      array (
        0 => 'Désactivé',
      ),
      'Enabled' => 
      array (
        0 => 'Activé',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Jours entre chaque affectations automatiques',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Basé sur ce paramètre, le système assignera automatiquement les titres chaque (X) jours, à l’aide des données provenant des derniers (X) jours.',
      ),
      '%d days' => 
      array (
        0 => '%d jours',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Exécuter des sauvegardes automatiques de nuit',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'Permet à AzuraCast d\'exécuter automatiquement des sauvegardes de nuit à l\'heure spécifiée.',
      ),
      'Yes' => 
      array (
        0 => 'Oui',
      ),
      'No' => 
      array (
        0 => 'Non',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Heure de la sauvegarde planifiée',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'Le délai (en UTC) d\'exécution de la sauvegarde automatique, si elle est activée.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Exclure les médias des sauvegardes',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere.' => 
      array (
        0 => 'Exclure les médias des sauvegardes automatiques vous permettra d\'économiser de l\'espace, mais vous devriez vous assurer de sauvegarder vos médias ailleurs.',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Nombre de copies des sauvegardes à conserver',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Les copies plus anciennes que le nombre de jours spécifié seront automatiquement supprimées. Mettez la valeur à zéro pour désactiver la suppression automatique.',
      ),
      'Backup Filename' => 
      array (
        0 => 'Nom de la sauvegarde',
      ),
      'Optional absolute or relative path where the backup file should be located.' => 
      array (
        0 => 'Facultatif : chemin absolu ou relatif où le fichier de sauvegarde doit se trouver.',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Exclure un média de la sauvegarde',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere.' => 
      array (
        0 => 'Cela produira une sauvegarde beaucoup plus petite, mais vous devriez vous assurer de sauvegarder votre média ailleurs.',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Thème de base pour les pages publiques',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Sélectionnez un thème à utiliser comme base pour les pages publiques de la station et la page de connexion.',
      ),
      'Light' => 
      array (
        0 => 'Clair',
      ),
      'Default' => 
      array (
        0 => 'Par défaut',
      ),
      'Dark' => 
      array (
        0 => 'Sombre',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Masquer les pochettes d\'album sur les pages publiques',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Si cette option est sélectionnée, les pochettes d\'album ne s\'afficheront pas sur les pages radio publiques.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL de redirection de la page d\'accueil',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Si un visiteur n\'est pas connecté et visite la page d\'accueil d\'AzuraCast, vous pouvez le rediriger automatiquement vers l\'URL indiquée ici. Laissez vide pour les rediriger vers l\'écran de connexion par défaut.',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'URL de pochette d\'album par défaut',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Si une chanson n\'a pas de pochette d\'album, cette URL sera affichée à la place. Laisser en blanc pour utiliser la pochette standard.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Masquer la marque AzuraCast sur les pages publiques',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Si cette option est sélectionnée, la marque AzuraCast sera supprimée des pages destinées au public.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'CSS personnalisé pour les pages publique',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Ce CSS sera appliqué aux pages publiques de la station et à la page de connexion.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'JS personnalisé pour les pages publique',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Ce code javascript sera appliqué aux pages publiques de la station et à la page de connexion.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'CSS personnalisé pour les pages internes',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Ce CSS sera appliqué aux pages de gestion, comme celle-ci.',
      ),
      'Field Name' => 
      array (
        0 => 'Nom du champ',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Ceci sera utilisé comme libellé lors de l\'édition de chansons individuelles et apparaîtra dans les résultats de l\'API.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Nom du programme',
      ),
      'Optionally specify an API-friendly name, such as <code>field_name</code>. Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => 'En option, spécifiez un nom convivial pour l\'API, tel que <code>field_name</code>. Laissez ce champ vide pour en créer un automatiquement en fonction du nom.',
      ),
      'Important Notes' => 
      array (
        0 => 'Notes Importantes',
      ),
      '<p>SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary. In order to install SHOUTcast, you should download the Linux x64 binary from the <a href="%s" target="_blank">SHOUTcast Radio Manager</a> web site. Upload the <code>sc_serv2_linux_x64-latest.tar.gz</code> into the field below to automatically extract it into the proper directory.</p>' => 
      array (
        0 => '<p>SHOUTcast 2 DNAS n\'est pas un logiciel libre, et sa licence restrictive ne permet pas à AzuraCast de distribuer le binaire SHOUTcast. Afin d\'installer SHOUTcast, vous devez télécharger le binaire Linux x64 depuis le répertoire<a href="%s" target="_blank">SHOUTcast</a> sur le site Web de l\'organisme. Téléchargez le fichier <code>sc_serv2_linux_x64-latest.tar.gz</code> dans le champ ci-dessous pour l\'extraire automatiquement dans le répertoire approprié.</p>',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Version actuelle installée',
      ),
      'SHOUTcast is not currently installed on this installation.' => 
      array (
        0 => 'SHOUTcast n\'est pas actuellement installé sur cette machine.',
      ),
      'Select SHOUTcast 64-bit .tar.gz File' => 
      array (
        0 => 'Sélectionner le fichier SHOUTcast 64bits. tar.gz',
      ),
      'Upload' => 
      array (
        0 => 'Envoyer',
      ),
      'E-mail Address' => 
      array (
        0 => 'Adresse e-mail',
      ),
      'Password' => 
      array (
        0 => 'Mot de passe',
      ),
      'Log in' => 
      array (
        0 => 'Se connecter',
      ),
      'File Name' => 
      array (
        0 => 'Nom du Fichier',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Le chemin relatif dans le répertoire des médias, pour cette station.',
      ),
      'Song Album' => 
      array (
        0 => 'Album de la musique',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Paroles de musique',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Remplacer la pochette de l\'album',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'L\'International Standard Recording Code, utilisé pour les licences de diffusion.',
      ),
      'Custom Fields' => 
      array (
        0 => 'Champs personnalisés',
      ),
      'Administrators can customize the fields that appear here in the <a href="%s">administration page</a>.' => 
      array (
        0 => 'Les administrateurs peuvent personnaliser les champs qui apparaissent ici sur la<a href="%s">page d\'administration</a>.',
      ),
      'Control Song Playback' => 
      array (
        0 => 'Lecture du morceau de contrôle',
      ),
      'Song Length (seconds)' => 
      array (
        0 => 'Durée du titre (en secondes)',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la superposition (en secondes)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Indique la durée quand ce titre sera superposé au titre suivant et précédent lors de la transition. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la transition de départ (en secondes)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Indique a quel moment cette musique commencera sa transition de départ. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la transition de fin (en secondes)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Indique a quel moment cette musique commencera sa transition de fin. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Repères personnalisés : Début du titre (en secondes)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'A quel moment, en secondes depuis le début, l\'AutoDJ commencera à lire ce titre.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Repères personnalisés : Fin du titre (en secondes)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'A quel moment, en secondes depuis le début, l\'AutoDJ arrêtera de lire ce titre.',
      ),
      'Mount Point URL' => 
      array (
        0 => 'URL du point de montage',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Ce nom doit toujours commencer par un slash (/) et doit être une URL valide, par exemple /autodj.mp3',
      ),
      'Display Name' => 
      array (
        0 => 'Nom d\'affichage',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Le nom d\'affichage attribué à ce point de montage lors de sa visualisation sur des pages administratives ou publiques. Laissez vide pour en générer automatiquement un.',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Afficher sur les pages publiques',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Permet de permettre aux auditeurs de sélectionner ce point de montage sur les pages publiques de cette station.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Définir comme point de montage par défaut',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Si ce point de montage est celui par défaut, il sera lu en premier sur l\'aperçu de la station et sur la page publique du système.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'URL du flux a relayer',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Entrez l’URL complète d’un autre flux pour relayer sa diffusion par le biais de ce point de montage.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => 'Publier dans les annuaires "Pages Jaunes"(Yellow Pages)',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Permet d\'annoncer ce point de montage dans les annuaires radiophoniques publics "Pages Jaunes"(Yellow Pages).',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'Activer l\'AutoDJ',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'Si cette option est activée, l\'AutoDJ jouera automatiquement de la musique sur ce point de montage.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'Format de l\'AutoDJ',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'Taux de l\'AutoDJ (Kb/s)',
      ),
      'Custom Stream URL' => 
      array (
        0 => 'URL de flux personnalisé',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'Vous pouvez définir une URL personnalisée pour ce flux qu\'AzuraCast utilisera pour s\'y référer. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Point de montage de secours',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Si ce point de montage ne joue plus d\'audio, les auditeurs seront redirigés automatiquement vers ce point. Par défaut /error.mp3, un message d\'erreur, sera lu.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Configuration personnalisée du front-end',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML &lt;key&gt;value&lt;/key&gt;' => 
      array (
        0 => 'Vous pouvez inclure des paramètres spéciaux pour ce point de montage, au format JSON { key: \'value\' } ou au format XML &lt;key&gt;value&lt;/key&gt;',
      ),
      'Stream path cannot include reserved keywords: %s' => 
      array (
        0 => 'Le chemin du flux ne peut pas inclure de mots-clés réservés : %s',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'Hash d\'autorisation d\'annuaire YP',
      ),
      'If your stream is set to advertise to YP directories above, you must specify an authorization hash. You can manage authhashes <a href="%s" target="_blank">on the SHOUTcast web site</a>.' => 
      array (
        0 => 'Si votre flux est configuré pour faire de la publicité dans les répertoires YP ci-dessus, vous devez spécifier un hachage d\'autorisation. Vous pouvez gérer les authhashes <a href="%s" target="_blank">sur le site de SHOUTcast</a>.',
      ),
      'Basic Information' => 
      array (
        0 => 'Renseignements de base',
      ),
      'Source' => 
      array (
        0 => 'Source',
      ),
      'Scheduling' => 
      array (
        0 => 'Calendrier',
      ),
      'Enable Playlist' => 
      array (
        0 => 'Activez la playlist',
      ),
      'If set to "No", the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Si la valeur est « Non », la playlist ne sera pas ajoutée dans la liste de lecture de la station, mais pourra toujours être gérée.',
      ),
      'Playlist Name' => 
      array (
        0 => 'Nom de la playlist',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Priorité de la playlist',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Les playlists aux priorités plus élevées joueront plus régulièrement que celle aux priorités plus basse.',
      ),
      'Low' => 
      array (
        0 => 'Faible',
      ),
      'High' => 
      array (
        0 => 'Élevée',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Playlist de différents titres',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Une playlist contenant les fichiers audio hébergés sur ce serveur.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Playlist URL distante',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Une playlist qui demande à la station de diffuser à partir d\'une URL distante.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Ordre de lecture des morceaux',
      ),
      'Shuffled' => 
      array (
        0 => 'Aléatoire',
      ),
      'Random' => 
      array (
        0 => 'Au hasard',
      ),
      'Sequential' => 
      array (
        0 => 'Séquentiel',
      ),
      'Import Existing Playlist' => 
      array (
        0 => 'Importer une playlist existante',
      ),
      'Select an existing playlist file to add its contents to this playlist. PLS and M3U are supported.' => 
      array (
        0 => 'Sélectionnez un fichier de playlist existant pour ajouter son contenu à cette liste de lecture. PLS et M3U sont pris en charge.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Autoriser les requêtes pour cette playlist',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Si les requêtes sont activées pour votre station, les utilisateurs pourront demander les médias qui se trouvent sur cette playlist.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Masquer les métadonnées aux auditeurs ("Mode Jingle")',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Activez ce paramètre pour empêcher l\'envoi de métadonnées à l\'AutoDJ pour les fichiers de cette playlist. Ceci est utile si la playlist contient des jingles ou des bumpers.',
      ),
      'Remote URL' => 
      array (
        0 => 'URL distante',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Type d\'URL à distance',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'URL de flux direct',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'URL de la playlist (M3U/PLS)',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Mémoire tampon de la diffusion (secondes)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'La durée du temps de lecture que Liquidsoap doit mettre en mémoire tampon lors de la lecture de cette playlist distante. Des durées courtes peuvent entraîner une lecture discontinue sur des connexions instables.',
      ),
      'General Rotation' => 
      array (
        0 => 'Rotation générale',
      ),
      'Plays all day, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Joue toute la journée, mélangée avec d’autres playlists basées sur leurs priorités.',
      ),
      'Scheduled' => 
      array (
        0 => 'Programmé',
      ),
      'Play during a scheduled time range.' => 
      array (
        0 => 'Jouez pendant un intervalle de temps programmé.',
      ),
      'Once per x Songs' => 
      array (
        0 => 'Une fois toutes les x musiques',
      ),
      'Play exactly once every <i>x</i> songs.' => 
      array (
        0 => 'Jouez exactement une fois toutes les <i>x</i> musiques.',
      ),
      'Once Per x Minutes' => 
      array (
        0 => 'Une fois toutes les x minutes',
      ),
      'Play exactly once every <i>x</i> minutes.' => 
      array (
        0 => 'Jouez exactement une fois toutes les <i>x</i> minutes.',
      ),
      'Once per Hour' => 
      array (
        0 => 'Une fois par heure',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Jouez une fois par heure à la minute spécifiée.',
      ),
      'Advanced' => 
      array (
        0 => 'Avancé',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration. <a href="%s" target="_blank">Learn about Advanced Playlists</a>' => 
      array (
        0 => 'Définissez manuellement comment cette liste de lecture est utilisée dans la configuration Liquidsoap. <a href="%s" target="_blank">En savoir plus sur les listes de lecture avancées</a>',
      ),
      'AutoDJ Scheduling Options' => 
      array (
        0 => 'Options de programmation AutoDJ',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Contrôlez la façon dont cette playlist est gérée par le logiciel AutoDJ.',
      ),
      '<b>Warning:</b> These functions are internal to Liquidsoap and will affect how your AutoDJ works.' => 
      array (
        0 => '<b>Attention :</b> Ces fonctions sont internes à Liquidsoap et affecteront le fonctionnement de votre AutoDJ.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Interruption de la lecture d\'autres chansons pour jouer à l\'heure prévue.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Boucler une seule fois la liste de lecture.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Lecture d\'un seul titre à l\'heure prévue.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Fusionner la liste de lecture pour jouer en une seule piste.',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Inclure dans l\'affectation automatique',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Si l\'Affectation Automatique est activée, cette playlist sera l\'une des destinations en cas de redistribution des titres. Ceci va écraser le contenu de cette playlist.',
      ),
      'Start Time' => 
      array (
        0 => 'Heure de début',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Pour diffuser une fois par jour, réglez les heures de début et de fin à la même valeur.',
      ),
      'End Time' => 
      array (
        0 => 'Heure de fin',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Si l\'heure de fin est antérieure à l\'heure de début, la playlist sera diffusée pendant la nuit.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Fuseau horaire de la station',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Jours de diffusion prévus pour la semaine',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Laisser vide pour jouer tous les jours de la semaine.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Nombre de musiques entre chaque lectures',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Cette playlist jouera chaque $x titres, où $x est indiqué ci-dessous.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Nombre de minutes entre chaque lecture',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Cette playlist jouera chaque $x minutes, où $x est indiqué ci-dessous.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Minute de diffusion pour chaque heure',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Spécifiez la minute pour chaque heure de diffusion de cette playlist.',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Utiliser la valeur du navigateur',
      ),
      'Name' => 
      array (
        0 => 'Nom',
      ),
      'Reset Password' => 
      array (
        0 => 'Réinitialiser le mot de passe',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Laissez ces champs vides pour continuer à utiliser votre mot de passe actuel.',
      ),
      'Current Password' => 
      array (
        0 => 'Mot de passe actuel',
      ),
      'New Password' => 
      array (
        0 => 'Nouveau mot de passe',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Confirmer le nouveau mot de passe',
      ),
      'Customization' => 
      array (
        0 => 'Personnalisation',
      ),
      'Language' => 
      array (
        0 => 'Langue',
      ),
      'Site Theme' => 
      array (
        0 => 'Thème du site',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Code de l\'application authentificateur',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Entrez le code actuel fourni par votre application d\'authentification pour vérifier qu\'il fonctionne correctement.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Vérifier l\'authentificateur',
      ),
      'Account Information' => 
      array (
        0 => 'Informations du compte',
      ),
      'Create Account' => 
      array (
        0 => 'Créer un compte',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Activez cette option pour permettre aux auditeurs de sélectionner ce relais sur les pages publiques de cette station.',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Type de station à distance',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Le nom d\'affichage attribué à ce relais lors de sa visualisation sur des pages administratives ou publiques. Laissez vide pour en générer automatiquement un.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'URL de la station distante',
      ),
      'Example: if the remote radio URL is %s, enter <code>%s</code>.' => 
      array (
        0 => 'Exemple : si l\'URL de la radio distante est %s, entrer <code>%s</code>.',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Station d\'écoute à distance Point de montage / SID',
      ),
      'Specify a mountpoint (i.e. <code>%s</code>) or a Shoutcast SID (i.e. <code>%s</code>) to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => 'Spécifiez un point de montage (i.e. <code>%s</code>) ou un SID Shoutcast (i.e. <code>%s</code>) pour spécifier un flux spécifique à utiliser pour les statistiques ou la diffusion.',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Diffusion AutoDJ vers la station distante',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Si cette option est activée, l\'AutoDJ de cette installation diffusera automatiquement de la musique à ce point de montage.',
      ),
      'Configure AutoDJ Broadcasting' => 
      array (
        0 => 'Configurer la diffusion AutoDJ',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Port source de la station distante',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Si le port vers lequel vous diffusez est différent de celui que vous avez indiqué dans l\'URL ci-dessus, indiquez ici le port source.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Station à distance Source Point de montage / SID',
      ),
      'If the mountpoint (i.e. <code>/radio.mp3</code>) or Shoutcast SID (i.e. <code>2</code>) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => 'Si le point de montage (c-à-d. <code>/radio.mp3</code>) ou le Shoutcast SID (c-à-d. <code>2</code>) vers lequel vous diffusez est différent de celui indiqué ci-dessus, indiquez ici le point de montage source.',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Nom d\'utilisateur source de la station distante',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'Si vous diffusez avec l\'AutoDJ, entrez le nom d\'utilisateur source ici. Il se peut que ce soit vide.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Mot de passe source de la station distante',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'Si vous diffusez avec l\'AutoDJ, entrez le mot de passe source ici.',
      ),
      'Role Name' => 
      array (
        0 => 'Nom du rôle',
      ),
      'System-Wide Permissions' => 
      array (
        0 => 'Permissions globales',
      ),
      'Permissions for %s' => 
      array (
        0 => 'Permissions for %s',
      ),
      'Site Base URL' => 
      array (
        0 => 'URL de base du site',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'L\'URL de base où se trouve ce service. Utilisez soit l\'IP externe, soit un nom de domaine complet (le cas échéant) pointant vers ce serveur.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'Nom de l\'instance AzuraCast',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Ce nom va apparaître comme sous-titre à côté du logo d\'AzuraCast, pour vous aider à identifier ce serveur.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'URL du navigateur préféré (si disponible)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Si ce paramètre est réglé sur "Oui", l\'URL du navigateur sera utilisé à la place de l\'URL de base lorsqu\'il sera disponible. Réglez sur "Non" pour toujours utiliser l\'URL de base.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Utiliser un Proxy Web pour la station',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Par défaut, les stations diffusent sur leurs propres port (par ex. 8000). Si vous utilisez un service comme CloudFlare ou que vous accédez à votre radio via SSL, vous devriez activer cette fonctionnalité qui dirigera la radio à travers les ports web (80 et 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Jours à conserver de l\'historique de lecture',
      ),
      'Set longer to preserve more playback history for stations. Set shorter to save disk space.' => 
      array (
        0 => 'Set longer to preserve more playback history for stations. Set shorter to save disk space.',
      ),
      'Last 14 Days' => 
      array (
        0 => '14 derniers jours',
      ),
      'Last 30 Days' => 
      array (
        0 => '30 derniers jours',
      ),
      'Last 60 Days' => 
      array (
        0 => '60 derniers jours',
      ),
      'Last Year' => 
      array (
        0 => 'L’an dernier',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Il y a deux ans',
      ),
      'Indefinitely' => 
      array (
        0 => 'Indéfiniment',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => 'Utiliser WebSockets pour les mises à jour de la musique en cours de diffusion',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => 'Activer ou désactiver l\'utilisation du système WebSocket, plus récent et plus rapide, pour recevoir des mises à jour en direct sur les lecteurs publics. Vous devrez peut-être désactiver cette fonction si vous rencontrez des problèmes avec cette fonctionnalité.',
      ),
      'Security Controls' => 
      array (
        0 => 'Contrôles de sécurité',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Toujours utiliser HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Réglez sur "Oui" pour toujours utiliser les URL sécurisées "https://" et pour rediriger automatiquement vers l\'URL sécurisée lorsqu\'une URL non sécurisée est visitée.',
      ),
      'Enable Built-in FTP Server' => 
      array (
        0 => 'Activer le serveur FTP intégré',
      ),
      'If enabled, users can connect via FTP using their AzuraCast credentials to upload media directly to any stations they manage.' => 
      array (
        0 => 'Si cette option est activée, les utilisateurs peuvent se connecter via FTP à l\'aide de leurs identifiants AzuraCast pour télécharger des médias directement sur les stations qu\'ils gèrent.',
      ),
      'API "Access-Control-Allow-Origin" header' => 
      array (
        0 => 'En-tête de l\'API "Access-Control-Allow-Origin"',
      ),
      '<a href="%s" target="_blank">Learn more about this header</a>. Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '<a href="%s" target="_blank">En savoir plus sur cet en-tête</a>. Définissez sur * pour autoriser toutes les sources, ou spécifiez une liste d\'origines séparées par une virgule (,).',
      ),
      'Privacy Controls' => 
      array (
        0 => 'Contrôles de protection de la vie privée',
      ),
      'AzuraCast does not send your station or listener data to any external server. You can control how much data AzuraCast logs about your listeners here.' => 
      array (
        0 => 'AzuraCast n\'envoie pas les données de votre station ou de vos auditeurs à un serveur externe. Vous pouvez contrôler la quantité de données qu\'AzuraCast enregistre sur vos auditeurs ici.',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Enregistrement des analyses des auditeurs',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Les statistiques globales sur les auditeurs sont utilisées pour afficher les rapports des stations dans l\'ensemble du système. Les statistiques d\'auditeurs basées sur IP sont utilisées pour visualiser le suivi des auditeurs en direct et peuvent être requises pour les rapports sur les redevances.',
      ),
      '<b>Full:</b> Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '<b>Complet :</b> Collecte de statistiques globales sur les auditeurs et de statistiques sur les auditeurs basées sur IP',
      ),
      '<b>Limited:</b> Only collect aggregate listener statistics' => 
      array (
        0 => '<b>Limité :</b> Recueillir uniquement des statistiques globales sur les auditeurs',
      ),
      '<b>None:</b> Do not collect any listener analytics' => 
      array (
        0 => '<b>Aucune :</b> Ne pas collecter d\'analyses de l\'auditeur',
      ),
      'AzuraCast Installation Telemetry' => 
      array (
        0 => 'Télémétrie d\'installation AzuraCast',
      ),
      'Choose whether your installation communicates with central AzuraCast servers to check for updates and announcements.<br>AzuraCast respects your privacy; see our <a href="%s" target="_blank">privacy policy</a> for more details.' => 
      array (
        0 => 'Choisissez si votre installation communique avec les serveurs centraux AzuraCast pour vérifier les mises à jour et les annonces.<br>AzuraCast respecte votre vie privée ; voir notre<a href="%s" target="_blank">politique de confidentialité</a> pour plus de détails.',
      ),
      'Check for Updates and Announcements' => 
      array (
        0 => 'Vérifier les mises à jour et les annonces',
      ),
      'Send minimal details about your AzuraCast installation to the AzuraCast central server to check for updated software releases and important announcements.' => 
      array (
        0 => 'Envoyez un minimum de détails sur votre installation AzuraCast au serveur central d\'AzuraCast pour vérifier les mises à jour des logiciels et les annonces importantes.',
      ),
      '<b>None:</b> Do not check for updates or announcements.' => 
      array (
        0 => '<b>Aucune :</b> Ne pas vérifier les mises à jour ou les annonces.',
      ),
      '<b>Release Only:</b> Critical announcements and new release versions only.' => 
      array (
        0 => '<b>Communiqué seulement :</b> Annonces critiques et nouvelles versions uniquement.',
      ),
      '<b>All Updates:</b> Include all announcements and minor updates.' => 
      array (
        0 => '<b>Toutes les mises à jour :</b> Inclure toutes les annonces et les mises à jour mineures.',
      ),
      'Automatically Send Error Reports to AzuraCast' => 
      array (
        0 => 'Envoyer automatiquement les rapports d\'erreurs à AzuraCast',
      ),
      'If the web application encounters an error, you can choose to automatically send an anonymized report of the error to the AzuraCast team for faster diagnosis and resolution.' => 
      array (
        0 => 'Si l\'application Web rencontre une erreur, vous pouvez choisir d\'envoyer automatiquement un rapport anonyme de l\'erreur à l\'équipe AzuraCast pour un diagnostic et une résolution plus rapide.',
      ),
      'Error reports are powered by <a href="%s" target="_blank">%s</a>.' => 
      array (
        0 => 'Les rapports d\'erreurs sont alimentés par<a href="%s" target="_blank">%s</a>.',
      ),
      'Metadata' => 
      array (
        0 => 'Métadonnées',
      ),
      'Full Text' => 
      array (
        0 => 'Texte complet',
      ),
      'Artist Name' => 
      array (
        0 => 'Nom de l’artiste',
      ),
      'Station Profile' => 
      array (
        0 => 'Profil de la station',
      ),
      'Broadcasting' => 
      array (
        0 => 'Diffusion',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Administration' => 
      array (
        0 => 'Administration',
      ),
      'Description' => 
      array (
        0 => 'Description',
      ),
      'Genre' => 
      array (
        0 => 'Genre',
      ),
      'Web Site URL' => 
      array (
        0 => 'URL du site Web',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => 'Remarque : Ceci devrait être la page d\'accueil de la station de radio, et non l\'URL AzuraCast. Il sera inclus dans les détails de la diffusion.',
      ),
      'Time Zone' => 
      array (
        0 => 'Fuseau horaire',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => 'Les playlists programmées et autres éléments programmés seront contrôlés par ce fuseau horaire.',
      ),
      'Enable Public Page' => 
      array (
        0 => 'Activer la page publique',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => 'Afficher la station dans les pages publiques et les résultats généraux de l\'API.',
      ),
      'URL Stub' => 
      array (
        0 => 'Bout d\'URL',
      ),
      'Optionally specify a short URL-friendly name, such as <code>my_station_name</code>, that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => 'Spécifiez éventuellement un nom court convivial pour l\'URL, tel que <code>my_station_name</code>, qui sera utilisé dans les URLs de cette station. Laissez ce champ vide pour en créer un automatiquement en fonction du nom de la station.',
      ),
      'Number of Recently Played Songs' => 
      array (
        0 => 'Nombre de chansons jouées récemment',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => 'Personnalisez le nombre de chansons qui apparaîtront dans la section "Historique des chansons" de cette station et dans toutes les API publiques.',
      ),
      'Broadcasting Service' => 
      array (
        0 => 'Service de diffusion',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => 'Ce logiciel transmet votre diffusion à vos auditeurs.',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => 'Personnaliser le port de diffusion',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Aucun autre programme ne peut utiliser ce port. Laissez vide pour assigner automatiquement un port.',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Auditeurs maximum',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default (250).' => 
      array (
        0 => 'Nombre maximum d\'auditeurs total à travers tous les streams. Laisser vide pour utiliser la valeur par défaut (250).',
      ),
      'Customize Source Password' => 
      array (
        0 => 'Personnaliser le mot de passe source',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Laissez vide pour générer automatiquement un nouveau mot de passe.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => 'Personnaliser le mot de passe administrateur',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Configuration personnalisée',
      ),
      'This code will be included in the frontend configuration. You can use either JSON {"new_key": "new_value"} format or XML &lt;new_key&gt;new_value&lt;/new_key&gt;.' => 
      array (
        0 => 'Ce code sera inclus dans la configuration du frontend. Vous pouvez utiliser le format JSON {"new_key": "new_value"} ou le format XML &lt;new_key&gt;new_value&lt;/new_key&gt;.',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'Service AutoDJ',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => 'Ce logiciel mélange les listes de lecture de musique en permanence et joue lorsque aucune autre source radio n\'est disponible.',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Méthode de fondu enchaîné',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Choisissez une méthode à utiliser lors de la transition d\'un morceau à un autre. Le mode intelligent prend en compte le volume des deux pistes lors du fondu pour un effet plus doux, mais nécessite plus de ressources CPU.',
      ),
      'Smart Mode' => 
      array (
        0 => 'Mode intelligent',
      ),
      'Normal Mode' => 
      array (
        0 => 'Mode normal',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Désactiver le fondu enchaîné',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Durée du fondu enchaîné (en secondes)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Nombre de secondes avant le chevauchement des chansons.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Appliquer la compression et la normalisation',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Compressez et normalisez l\'audio de votre station, produisant un son plus uniforme et "plein".',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Autoriser la demande du titre suivant',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Permettez aux auditeurs de demander une chanson à écouter sur votre station. Seules les chansons qui sont déjà dans vos listes de lecture sont interrogeables.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Délai minimum des demandes (en minutes)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, no delay is applied.<br><b>Important:</b> Some stream licensing rules require a minimum delay for requests (in the US, this is currently 60 minutes). Check your local regulations for more information.' => 
      array (
        0 => 'Si les demandes sont activées, vous pouvez spécifier un délai (en minutes) entre la demande et le moment où il est joué. Si la valeur est zéro, aucun retard n’est appliqué. <br><b>Important :</b> certaines lois sur la diffusion exigent un délai minimum pour les demandes (aux États-Unis, c’est actuellement à 60 minutes). Veuillez vérifier vos lois locales pour plus d’informations.',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'Temps d\'attente avant de redemander un titre (en minutes)',
      ),
      'If requests are enabled, this specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => 'Si les requêtes sont activés, ceci permet de spécifier le temps minimum (en minutes) entre le moment où le titre est joué à la radio et quand il peut être demandé à nouveau. Spécifiez 0 pour aucune attente.',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'Permettre les streamers / DJs',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => 'Si cette option est activée, les streamers (ou DJ) pourront se connecter directement à votre flux et diffuser de la musique en direct qui interrompt le flux AutoDJ.',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => 'Désactiver le Streamer à la déconnexion (secondes)',
      ),
      'Number of seconds to deactivate station streamer on manual disconnect. Set to 0 to disable deactivation completely.' => 
      array (
        0 => 'Nombre de secondes pour désactiver le streamer de la station en cas de déconnexion manuelle. Réglez à 0 pour désactiver complètement la désactivation.',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => 'Personnaliser le port DJ/Streamer',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.<br><b>Note:</b> The port after this one (n+1) will automatically be used for legacy connections.' => 
      array (
        0 => 'Aucun autre programme ne peut utiliser ce port. Laisser vide pour assigner automatiquement un port.<br><b>Note :</b> Le port suivant (n+1) sera automatiquement utilisé pour les connexions héritées.',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => 'Personnaliser le port de traitement des demandes internes',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Ce port n\'est utilisé par aucun processus externe. Ne modifiez ce port que si le port assigné est utilisé. Laisser vide pour assigner automatiquement un port.',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => 'Temps de buffer DJ/Streamer (secondes)',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => 'Le nombre de secondes de signal à mémoriser en cas d\'interruption. Réglez la valeur la plus basse que vos DJs peuvent utiliser sans interruption de flux.',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => 'Personnaliser le point de montage DJ/Streamer',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => 'Si votre logiciel de streaming nécessite un chemin de point de montage spécifique, indiquez-le ici. Sinon, utilisez la valeur par défaut.',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => 'Utiliser les métadonnées Replaygain',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => 'Demandez à Liquidsoap d\'utiliser toutes les métadonnées de relecture associées à un morceau pour contrôler son niveau de volume.',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => 'Mode manuel de l\'AutoDJ',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => 'Ce mode désactive la gestion AutoDJ d\'AzuraCast, utilisant Liquidsoap pour gérer la lecture des morceaux. Diverses fonctionnalités comme "Chanson suivante" ne seront pas disponibles.',
      ),
      'Character Set Encoding' => 
      array (
        0 => 'Encodage des jeux de caractères',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => 'Dans la plupart des cas, utilisez l\'encodage UTF-8 par défaut. L\'ancien codage ISO-8859-1 peut être utilisé si vous acceptez les connexions des DJs SHOUTcast 1 ou si vous utilisez un autre logiciel existant.',
      ),
      'This code will be inserted into your station\'s Liquidsoap configuration, below the playlist configuration and just before the Icecast output. Only use valid Liquidsoap code for this section!' => 
      array (
        0 => 'Ce code sera inséré dans la configuration Liquidsoap de votre station, sous la configuration de la playlist et juste avant la sortie Icecast. Utilisez uniquement le code Liquidsoap valide pour cette section !',
      ),
      'Enable Broadcasting' => 
      array (
        0 => 'Autoriser la diffusion',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => 'Si elle est désactivée, la station ne diffusera pas ou ne mélangera pas son AutoDJ.',
      ),
      'Storage Quota' => 
      array (
        0 => 'Quota de stockage',
      ),
      'Set a maximum disk space that this station can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => 'Définissez un espace disque maximum que cette station peut utiliser. Spécifiez la taille avec l\'unité, c\'est-à-dire "8 Go". Les unités sont mesurées en 1024 octets. Laisser vide par défaut en fonction de l\'espace disponible sur le disque.',
      ),
      'Base Station Directory' => 
      array (
        0 => 'Répertoire des stations de base',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Le répertoire parent dans lequel sont stockés la liste de lecture et les fichiers de configuration des stations. Laisser vide pour utiliser le répertoire par défaut.',
      ),
      'Custom Media Directory' => 
      array (
        0 => 'Répertoire personnalisé des médias',
      ),
      'The directory where media files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Le répertoire où sont stockés les fichiers multimédias. Laissez vide pour utiliser le répertoire par défaut.',
      ),
      'New Station Name' => 
      array (
        0 => 'Nouveau nom de station',
      ),
      'New Station Description' => 
      array (
        0 => 'Nouvelle description de la station',
      ),
      'Customize Station Cloning' => 
      array (
        0 => 'Personnalisation du clonage de la station',
      ),
      'Copy Media?' => 
      array (
        0 => 'Copier les médias ?',
      ),
      'Choose how media should be duplicated from the old station.' => 
      array (
        0 => 'Choisissez comment les médias doivent être dupliqués de l\'ancienne station.',
      ),
      'Do not share or copy media between the stations' => 
      array (
        0 => 'Ne pas partager ou copier les médias entre les stations',
      ),
      'Share the same folder on disk between the stations' => 
      array (
        0 => 'Partager le même dossier sur le disque entre les stations',
      ),
      'Copy the existing station\'s media to the new station' => 
      array (
        0 => 'Copier les médias de la station existante vers la nouvelle station',
      ),
      'Copy Playlists?' => 
      array (
        0 => 'Copier les playlists ?',
      ),
      'Copy Streamer/DJ Accounts?' => 
      array (
        0 => 'Copier les comptes des streamers / DJs ?',
      ),
      'Copy Permissions?' => 
      array (
        0 => 'Copier les permissions ?',
      ),
      'Selecting "Yes" will assign any users with permissions to the current station to have permissions to the new one.' => 
      array (
        0 => 'Sélectionner "Oui" va assigner à tous les utilisateurs qui ont accès à cette station les mêmes permissions vers la nouvelle station.',
      ),
      'Create New Station' => 
      array (
        0 => 'Créer une nouvelle station',
      ),
      'Account is Active' => 
      array (
        0 => 'Le compte est actif',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Activez cette option pour permettre à ce compte de se connecter et de diffuser en continu.',
      ),
      'Streamer Username' => 
      array (
        0 => 'Nom d’utilisateur du streamer',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'Le streamer utilisera ce nom d’utilisateur pour se connecter au serveur radio.',
      ),
      'Streamer Password' => 
      array (
        0 => 'Mot de passe du streamer',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => 'Le streamer utilisera ce mot de passe pour se connecter au serveur radio.',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'Nom d\'affichage du streamer',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => 'C\'est le nom de l\'affichage informel qui sera affiché dans les réponses API si le streamer/DJ est en direct.',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Notes internes ou commentaires au sujet de l’utilisateur, visible uniquement sur ce panneau de contrôle.',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Laissez vide pour garder le mot de passe actuel.',
      ),
      'Roles' => 
      array (
        0 => 'Rôles',
      ),
      'Web Hook Name' => 
      array (
        0 => 'Nom du Web Hook',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => 'Choisissez un nom pour ce Webhook qui vous aidera à le distinguer des autres. Ceci ne sera affiché que sur la page d\'administration.',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => 'URL Webhook de Discord',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => 'Cette URL est fournie dans l\'application Discord.',
      ),
      'Web Hook Triggers' => 
      array (
        0 => 'Déclencheurs de Webhook',
      ),
      'Customize Message' => 
      array (
        0 => 'Personnaliser le message',
      ),
      'Variables are in the form of <code>{{ var.name }}</code>. All values in the <a href="%s" target="_blank">Now Playing API response</a> are avaliable for use. Any empty fields are ignored.' => 
      array (
        0 => 'Les variables se présentent sous la forme de <code>{{ var.name }}</code>. Toutes les valeurs dans le champ <a href="%s" target="_blank">Réponse de l\'API de la lecture en cours</a> sont disponibles pour utilisation. Tous les champs vides sont ignorés.',
      ),
      'Main Message Content' => 
      array (
        0 => 'Contenu du message principal',
      ),
      'Now playing on %s:' => 
      array (
        0 => 'Maintenant on joue sur %s :',
      ),
      'Title' => 
      array (
        0 => 'Titre',
      ),
      'URL' => 
      array (
        0 => 'URL',
      ),
      'Author Name' => 
      array (
        0 => 'Nom de l\'auteur',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => 'URL de la vignette',
      ),
      'Footer Text' => 
      array (
        0 => 'Texte de bas de page',
      ),
      'Powered by %s' => 
      array (
        0 => 'Propulsé par %s',
      ),
      'Web Hook Details' => 
      array (
        0 => 'Détails du Webhook',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to 
                notify it any time one of the triggers you specify occurs on your station. The body of the POST message
                is the exact same as the <a href="%s" target="_blank">Now Playing API response</a> for your station. 
                In order to process quickly, web hooks have a short timeout, so the responding service should be
                optimized to handle the request in under 2 seconds.' => 
      array (
        0 => 'Les Web Hooks envoient automatiquement une requête HTTP POST à l\'URL que vous spécifiez aux 

déclencheurs que vous spécifiez se produisent sur votre station. Le corps du message POST

le <a href="%s" target="_blank">Réponse de l\'API de la diffusion en cours</a> pour votre station.

rapidement, les Web Hooks ont un court délai d\'attente, donc le service de réponse devrait être

exécuté en moins de 2 secondes.',
      ),
      'Web Hook URL' => 
      array (
        0 => 'URL du Webhook',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => 'URL qui recevra les messages POST chaque fois qu\'un événement est déclenché.',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => 'Optionnel : Nom d\'utilisateur pour l\'authentification de base HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => 'Si votre Webhook nécessite une authentification de base HTTP, indiquez le nom d\'utilisateur ici.',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => 'Optionnel : Mot de passe d\'authentification de base HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => 'Si votre Webhook nécessite une authentification de base HTTP, indiquez le mot de passe ici.',
      ),
      'Bot Token' => 
      array (
        0 => 'Jeton(Token) de Bot',
      ),
      'See the <a href="%s" target="_blank">Telegram Documentation</a> for more details.' => 
      array (
        0 => 'Voir la <a href="%s" target="_blank">documentation Telegram</a> pour plus de détails.',
      ),
      'Chat ID' => 
      array (
        0 => 'ID du Chat',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => 'Identificateur unique pour le chat cible ou le nom d\'utilisateur du canal cible (au format @channelusername).',
      ),
      'Custom API Base URL' => 
      array (
        0 => 'URL de base de l\'API personnalisée',
      ),
      'Leave blank to use the default Telegram API URL (recommended). Specify the full URL, like <code>https://api.pwrtelegram.xyz/</code>.' => 
      array (
        0 => 'Laisser vide pour utiliser l\'URL par défaut de l\'API de Telegram (recommandé). Spécifiez l\'URL complète, comme <code>https://api.pwrtelegram.xyz/</code>.',
      ),
      'Now playing on %s: %s by %s! Tune in now.' => 
      array (
        0 => 'Actuellement en train de diffuser %s : %s par %s ! Branchez-vous maintenant.',
      ),
      'Message parsing mode' => 
      array (
        0 => 'Mode d\'analyse des messages',
      ),
      'TuneIn Station ID' => 
      array (
        0 => 'TuneIn Station ID',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => 'L\'ID de la station sera une chaîne numérique commençant par la lettre S.',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => 'ID partenaire TuneIn',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => 'Clé de partenaire TuneIn',
      ),
      'Twitter Account Details' => 
      array (
        0 => 'Détails du compte Twitter',
      ),
      'Steps for configuring a Twitter application:<br>
                <ol type="1">
                    <li>Create a new app on the <a href="%s" target="_blank">Twitter Applications site</a>. 
                    Use this installation\'s base URL as the application URL.</li>
                    <li>In the newly created application, click the "Keys and Access Tokens" tab.</li>
                    <li>At the bottom of the page, click "Create my access token".</li>
                </ol>
                <p>Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.</p>' => 
      array (
        0 => 'Étapes de configuration d\'une application Twitter :<br>
             <ol type="1">
                     <li>Créez une nouvelle application sur la page<a href="%s" target="_blank">Site d\'applications Twitter</a>.
             Utilisez l\'URL de base de cette installation comme URL d\'application.</li>
                    <li>Dans l\'application nouvellement créée, cliquez sur l\'onglet "Clés et jetons d\'accès".</li>
             <li>En bas de la page, cliquez sur "Créer mon code d\'accès".</li>
            </ol>
<p>Une fois ces étapes terminées, entrez les informations de la page "Clés et jetons d\'accès" dans les champs ci-dessous.</p>',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => 'Clé consommateur (clé API)',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => 'Secret du consommateur (secret de l\'API)',
      ),
      'Access Token' => 
      array (
        0 => 'Jeton d\'accès',
      ),
      'Access Token Secret' => 
      array (
        0 => 'Access Token Secret',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => 'N\'envoyez qu\'un seul Tweet tous les...',
      ),
      'No Limit' => 
      array (
        0 => 'Aucune limite',
      ),
      '%d seconds' => 
      array (
        0 => '%d secondes',
      ),
      '%d minutes' => 
      array (
        0 => '%d minutes',
      ),
      'Message Body' => 
      array (
        0 => 'Corps du message',
      ),
      'System Maintenance' => 
      array (
        0 => 'Maintenance système',
      ),
      'Custom Branding' => 
      array (
        0 => 'Personnalisation de l\'image de marque',
      ),
      'API Keys' => 
      array (
        0 => 'Clés API',
      ),
      'System Logs' => 
      array (
        0 => 'Journaux(Logs) du système',
      ),
      'Audit Log' => 
      array (
        0 => 'Journal d\'audit',
      ),
      'Backups' => 
      array (
        0 => 'Sauvegardes',
      ),
      'Users' => 
      array (
        0 => 'Utilisateurs',
      ),
      'User Accounts' => 
      array (
        0 => 'Comptes utilisateurs',
      ),
      'Permissions' => 
      array (
        0 => 'Permissions',
      ),
      'Stations' => 
      array (
        0 => 'Stations',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'RelaisAzura connectés',
      ),
      'Start Station' => 
      array (
        0 => 'Démarrer la station',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Prêt à diffuser ? Cliquez pour démarrer votre station.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Redémarrer pour appliquer les modifications',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Cliquez pour redémarrer votre station et appliquer les modifications de configuration.',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Public Page' => 
      array (
        0 => 'Page publique',
      ),
      'Music Files' => 
      array (
        0 => 'Fichiers musicaux',
      ),
      'Playlists' => 
      array (
        0 => 'Playlists',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Comptes des streamers/DJs',
      ),
      'Web DJ' => 
      array (
        0 => 'Web DJ',
      ),
      'Mount Points' => 
      array (
        0 => 'Points de montage',
      ),
      'Remote Relays' => 
      array (
        0 => 'Relais distant',
      ),
      'Web Hooks' => 
      array (
        0 => 'Webhooks',
      ),
      'Reports' => 
      array (
        0 => 'Rapports',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Récapitulatif des statistiques',
      ),
      'Song Requests' => 
      array (
        0 => 'Demandes de titres',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Historique des titres',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Impact sur le nombre d\'auditeurs',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Titres en double',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'SoundExchange Royalties',
      ),
      'Utilities' => 
      array (
        0 => 'Utilitaires',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Affectation automatique',
      ),
      'Log Viewer' => 
      array (
        0 => 'Visionneuse de logs',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'File d\'attente des chansons à venir',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Redémarrer la diffusion',
      ),
      'Generic Web Hook' => 
      array (
        0 => 'Webhook générique',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => 'Envoyez automatiquement un message à n\'importe quelle URL lorsque les données de votre station changent.',
      ),
      'TuneIn AIR' => 
      array (
        0 => 'TuneIn AIR',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => 'Envoyer les changements de métadonnées de morceau à TuneIn.',
      ),
      'Discord Webhook' => 
      array (
        0 => 'Discord Webhook',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => 'Envoyez automatiquement un message personnalisé sur votre serveur Discord.',
      ),
      'Telegram Chat Message' => 
      array (
        0 => 'Message Telegram',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => 'Utilisez l\'API Telegram Bot pour envoyer un message à un canal.',
      ),
      'Twitter Post' => 
      array (
        0 => 'Post Twitter',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => 'Envoyer automatiquement un tweet.',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => 'Chaque fois que la chanson en cours de lecture change',
      ),
      'Any time the listener count increases' => 
      array (
        0 => 'Chaque fois que le nombre d\'auditeurs augmente',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => 'Chaque fois que le nombre d\'auditeurs diminue',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => 'Chaque fois qu\'un streamer en direct/DJ se connecte en direct sur le flux',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => 'Chaque fois qu\'un streamer en direct/DJ se déconnecte du flux',
      ),
      'API Key' => 
      array (
        0 => 'Clé API',
      ),
      'Owner' => 
      array (
        0 => 'Propriétaire',
      ),
      'Edit' => 
      array (
        0 => 'Éditer',
      ),
      'Revoke' => 
      array (
        0 => 'Révoquer',
      ),
      'Insert' => 
      array (
        0 => 'Insérer',
      ),
      'Delete' => 
      array (
        0 => 'Supprimer',
      ),
      'Update' => 
      array (
        0 => 'Mise à jour',
      ),
      'Changes' => 
      array (
        0 => 'Changements',
      ),
      'Today' => 
      array (
        0 => 'Aujourd’hui',
      ),
      'Yesterday' => 
      array (
        0 => 'Hier',
      ),
      'Last 7 Days' => 
      array (
        0 => '7 derniers jours',
      ),
      'This Month' => 
      array (
        0 => 'Ce mois-ci',
      ),
      'Last Month' => 
      array (
        0 => 'Le mois dernier',
      ),
      'Date/Time' => 
      array (
        0 => 'Date/Heure',
      ),
      'User' => 
      array (
        0 => 'Utilisateur',
      ),
      'Identifier' => 
      array (
        0 => 'Identifiant',
      ),
      'Target' => 
      array (
        0 => 'Cible',
      ),
      'Actions' => 
      array (
        0 => 'Actions',
      ),
      'Field' => 
      array (
        0 => 'Champ',
      ),
      'Previous' => 
      array (
        0 => 'Précédent',
      ),
      'Updated' => 
      array (
        0 => 'Mise à jour',
      ),
      'Automatic Backups' => 
      array (
        0 => 'Sauvegardes automatiques',
      ),
      'Last run: %s' => 
      array (
        0 => 'Dernière exécution : %s',
      ),
      'Never run' => 
      array (
        0 => 'Jamais exécuté',
      ),
      'Configure' => 
      array (
        0 => 'Configurer',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => 'Journaux de sauvegardes les plus récents',
      ),
      'Restoring Backups' => 
      array (
        0 => 'Restauration des sauvegardes',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => 'Pour restaurer une sauvegarde à partir de votre ordinateur hôte, exécutez :',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => 'Notez que la restauration d\'une sauvegarde effacera votre base de données existante. Ne restaurez jamais les fichiers de sauvegarde d\'utilisateurs non fiables.',
      ),
      'Backup' => 
      array (
        0 => 'Sauvegarde',
      ),
      'Last Modified' => 
      array (
        0 => 'Dernière modification',
      ),
      'Size' => 
      array (
        0 => 'Taille',
      ),
      'Download' => 
      array (
        0 => 'Télécharger',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => 'Supprimer la sauvegarde "%s"?',
      ),
      'Backups Home' => 
      array (
        0 => 'Accueil des sauvegardes',
      ),
      'Backup was run successfully.' => 
      array (
        0 => 'La sauvegarde a été exécutée avec succès.',
      ),
      'Backup encountered errors when running. Check the log below for details.' => 
      array (
        0 => 'La sauvegarde a rencontré des erreurs lors de son exécution. Consultez le journal ci-dessous pour plus de détails.',
      ),
      'Delete custom field "%s"?' => 
      array (
        0 => 'Supprimer le champ personnalisé "%s" ?',
      ),
      'Server Status' => 
      array (
        0 => 'Statut du serveur',
      ),
      'Current CPU Load' => 
      array (
        0 => 'Charge actuelle du processeur',
      ),
      '15-Minute CPU Load Average' => 
      array (
        0 => 'Moyenne de la charge du processeur sur 15 minutes',
      ),
      '%s of %s Used' => 
      array (
        0 => '%s de %s utilisé',
      ),
      'Synchronization Tasks' => 
      array (
        0 => 'Tâches de synchronisation',
      ),
      'Run Task' => 
      array (
        0 => 'Exécuter la tâche',
      ),
      'SHOUTcast Installed' => 
      array (
        0 => 'SHOUTcast est installé',
      ),
      'The SHOUTcast 2 DNAS is installed and ready for use.' => 
      array (
        0 => 'Le DNAS SHOUTcast 2 est installé et prêt à être utilisé.',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => 'Comme vous exécutez Docker, certains logs système ne sont accessibles qu\'à partir d\'une session shell sur le serveur hôte. Vous pouvez exécuter <code>%s</code> pour accéder aux logs des conteneurs depuis le terminal.',
      ),
      'Logs by Station' => 
      array (
        0 => 'Logs par station',
      ),
      'Delete role "%s"?' => 
      array (
        0 => 'Supprimer le rôle "%s" ?',
      ),
      'This role cannot be deleted.' => 
      array (
        0 => 'Ce rôle ne peut pas être supprimé.',
      ),
      'Global' => 
      array (
        0 => 'Globale',
      ),
      'Relay' => 
      array (
        0 => 'Relais',
      ),
      'Is Public' => 
      array (
        0 => 'Est publique',
      ),
      'First Connected' => 
      array (
        0 => 'Premier connecté',
      ),
      'Latest Update' => 
      array (
        0 => 'Dernière mise à jour',
      ),
      'Manage Stations' => 
      array (
        0 => 'Gestion des stations',
      ),
      'Add Station' => 
      array (
        0 => 'Ajouter une station',
      ),
      'Station' => 
      array (
        0 => 'Station',
      ),
      'Manage' => 
      array (
        0 => 'Gérer',
      ),
      'Clone' => 
      array (
        0 => 'Dupliquer',
      ),
      'Delete station "%s"?' => 
      array (
        0 => 'Supprimer la station "%s" ?',
      ),
      'Log In' => 
      array (
        0 => 'Se connecter',
      ),
      'Delete user "%s"?' => 
      array (
        0 => 'Supprimer l\'utilisateur "%s" ?',
      ),
      '(You)' => 
      array (
        0 => '(Vous)',
      ),
      'Welcome!' => 
      array (
        0 => 'Bienvenue!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Bienvenue sur %s !',
      ),
      'name@example.com' => 
      array (
        0 => 'name@example.com',
      ),
      'Enter your password' => 
      array (
        0 => 'Saisissez votre mot de passe',
      ),
      'Sign in' => 
      array (
        0 => 'Se connecter',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Veuillez vous connecter pour continuer.',
      ),
      '<a href="%s" target="_blank">Forgot your password?</a>' => 
      array (
        0 => '<a href="%s" target="_blank">vous avez oublié votre mot de passe ?</a>',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => 'Entrer le code à deux facteurs',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => 'Votre compte utilise un code de sécurité à deux facteurs. Entrez le code que votre appareil affiche actuellement ci-dessous.',
      ),
      'Security Code' => 
      array (
        0 => 'Code de sécurité',
      ),
      'My API Keys' => 
      array (
        0 => 'Mes clés API',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys 
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => 'Les clés API peuvent être utilisées pour accéder à certaines fonctionnalités du système sans avoir besoin de se connecter. Toutes les clés
         que vous créez partagent vos permissions dans le système. Pour plus d\'informations, voir la section<a href="%s">Documentation de l\'API</a>.',
      ),
      'Key Identifier' => 
      array (
        0 => 'Identificateur de clef',
      ),
      'New Key Generated' => 
      array (
        0 => 'Nouvelle clé générée',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '<b>Important : copiez la clé ci-dessous avant de continuer !</b> Vous ne pourrez plus la consulter.',
      ),
      'Your full API key is below:' => 
      array (
        0 => 'Votre clé API complète est ci-dessous :',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Copier dans le presse-papier',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => 'Lors des appels API, vous pouvez passer cette valeur dans l\'en-tête "X-API-Key" pour vous authentifier. Vous ne pouvez effectuer que les actions que votre compte utilisateur est autorisé à effectuer.',
      ),
      'Continue' => 
      array (
        0 => 'Continuer',
      ),
      'Dashboard' => 
      array (
        0 => 'Tableau de bord',
      ),
      'AzuraCast User' => 
      array (
        0 => 'Utilisateur AzuraCast',
      ),
      'My Account' => 
      array (
        0 => 'Mon compte',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Auditeurs par station',
      ),
      'Station Overview' => 
      array (
        0 => 'Vue d’ensemble de la station',
      ),
      'Station Name' => 
      array (
        0 => 'Nom de la station',
      ),
      'Now Playing' => 
      array (
        0 => 'Titre en cours',
      ),
      'Error: No Available Stations' => 
      array (
        0 => 'Erreur : Aucune station disponible',
      ),
      'Your account is active, but is not currently associated with any stations. If you believe this is an error, please contact this server\'s administrator.' => 
      array (
        0 => 'Votre compte est actif, mais n\'est actuellement associé à aucune station. Si vous pensez qu\'il s\'agit d\'une erreur, veuillez contacter l\'administrateur du serveur.',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'Activer l\'authentification à deux facteurs',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Étape 1 : Scanner le QR Code',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'Depuis votre smartphone, scannez le code vers la droite à l\'aide d\'une application d\'authentification de votre choix (FreeOTP, Authy, etc).',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Étape 2 : Vérification du code généré',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'Pour vérifier que le code a été correctement configuré, entrez le code à 6 chiffres que l\'application vous montre.',
      ),
      'QR-Code' => 
      array (
        0 => 'QR code',
      ),
      'Customize' => 
      array (
        0 => 'Personnaliser',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'Authentification à deux facteurs',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'L\'authentification à deux facteurs améliore la sécurité de votre compte en exigeant un deuxième code d\'accès unique en plus de votre mot de passe lorsque vous ouvrez une session.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'Désactiver l\'authentification à deux facteurs',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'Activer l\'authentification à deux facteurs',
      ),
      'Microphone' => 
      array (
        0 => 'Microphone',
      ),
      'Settings' => 
      array (
        0 => 'Paramètres',
      ),
      'Mixer' => 
      array (
        0 => 'Mélangeur',
      ),
      'Playlist 1' => 
      array (
        0 => 'Playlist 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Playlist 2',
      ),
      'Encoder' => 
      array (
        0 => 'Encodeur',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => 'Brut',
      ),
      'Sample Rate' => 
      array (
        0 => 'Fréquence d\'échantillonnage',
      ),
      'Bit Rate' => 
      array (
        0 => 'Débit',
      ),
      'DJ Credentials' => 
      array (
        0 => 'Identifiant DJ',
      ),
      'Username' => 
      array (
        0 => 'Nom d’utilisateur',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => 'Utiliser une tâche asynchrone',
      ),
      'Artist' => 
      array (
        0 => 'Artiste',
      ),
      'Continuous Play' => 
      array (
        0 => 'Lecture continue',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Répéter la playlist',
      ),
      'Microphone Source' => 
      array (
        0 => 'Source du microphone',
      ),
      'Start Streaming' => 
      array (
        0 => 'Démarrer la diffusion',
      ),
      'Stop Streaming' => 
      array (
        0 => 'Arrêter la diffusion',
      ),
      'Cue' => 
      array (
        0 => 'Cue',
      ),
      'Update Metadata' => 
      array (
        0 => 'Mettre à jour les métadonnées',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Ajouter des fichiers à la playlist',
      ),
      'Unknown Title' => 
      array (
        0 => 'Titre inconnu',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Artiste inconnu',
      ),
      'Request' => 
      array (
        0 => 'Demander',
      ),
      'Album' => 
      array (
        0 => 'Album',
      ),
      'Song History' => 
      array (
        0 => 'Historique des titres',
      ),
      'Request Song' => 
      array (
        0 => 'Demander un titre',
      ),
      'Playlist' => 
      array (
        0 => 'Playlist',
      ),
      'Request a Song' => 
      array (
        0 => 'Demander un titre',
      ),
      'Live' => 
      array (
        0 => 'Live',
      ),
      'Play' => 
      array (
        0 => 'Lecture',
      ),
      'Pause' => 
      array (
        0 => 'Pause',
      ),
      'Mute' => 
      array (
        0 => 'Mettre en sourdine',
      ),
      'Volume' => 
      array (
        0 => 'Volume',
      ),
      'Full Volume' => 
      array (
        0 => 'Volume maximum',
      ),
      'Album Art' => 
      array (
        0 => 'Pochette d\'album',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => 'AzuraCast Première installation',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'Bienvenue sur AzuraCast !',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => 'Commençons par créer votre compte Super Administrateur.',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => 'Ce compte aura un accès complet au système, et vous y serez automatiquement connecté pour le reste de l\'installation.',
      ),
      'Create Station' => 
      array (
        0 => 'Créer une station',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Compléter le processus d’installation en fournissant des informations sur votre environnement de diffusion. Ces paramètres peuvent être modifiés ultérieurement depuis le panneau d’administration.',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => 'Personnaliser les paramètres d\'AzuraCast',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Poursuivez le processus de configuration en créant votre première station de radio ci-dessous. Vous pourrez modifier ces détails plus tard.',
      ),
      'Create a New Radio Station' => 
      array (
        0 => 'Créer une nouvelle station de radio',
      ),
      'Skip to main content' => 
      array (
        0 => 'Passer au contenu principal',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Afficher/Masquer le panneau latéral',
      ),
      'Toggle Menu' => 
      array (
        0 => 'Basculer le menu',
      ),
      'System Administration' => 
      array (
        0 => 'Administration du système',
      ),
      'Switch Theme' => 
      array (
        0 => 'Changer de thème',
      ),
      'Help' => 
      array (
        0 => 'Aide',
      ),
      'End Session' => 
      array (
        0 => 'Fin de session',
      ),
      'Sign Out' => 
      array (
        0 => 'Se déconnecter',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'Vous aimez notre logiciel ? <a href="%s" target="_blank">Faites un don pour soutenir AzuraCast !</a>',
      ),
      'Mascot designed by %s' => 
      array (
        0 => 'Mascotte conçue par %s',
      ),
      'Need Help?' => 
      array (
        0 => 'Avez-vous besoin d’aide ?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => 'Vous trouverez les réponses à de nombreuses questions courantes dans notre rubrique <a href="%s" target="_blank">documents de support</a>.',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => 'Si vous rencontrez un bug ou une erreur, vous pouvez soumettre un rapport sur GitHub en utilisant le lien ci-dessous.',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => 'Votre installation actuelle est la <b>%s</b>. Assurez-vous de l\'inclure lors de la création d\'un nouveau problème.',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => 'Ajouter un nouveau problème sur GitHub',
      ),
      'Log View' => 
      array (
        0 => 'Visionneuse de journaux',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => 'Défilement automatique jusqu\'au bas du log',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Affectation de la playlist automatique',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => 'Basé sur le rendement antérieur des chansons de votre station, %s peut distribuer automatiquement les chansons uniformément dans vos listes de lecture, plaçant les titres les plus performants dans les listes de lecture plus fréquentes.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'Une fois que vous avez configuré l\'affectation automatique, cliquez sur le bouton ci-dessous pour lancer le processus de redistribution automatique. Ce processus ne se lancera pas tant que vous n\'aurez pas activé l\'option ci-dessous.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Exécuter l’affectation automatique',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Configurer l\'affectation automatique',
      ),
      'Delete {NUM} media file(s)?' => 
      array (
        0 => 'Supprimer {NUM} fichier(s) ?',
      ),
      'Files removed:' => 
      array (
        0 => 'Fichiers supprimés :',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Mise à jour des playlists pour les fichiers sélectionnés :',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Playlists effacées pour les fichiers sélectionnés :',
      ),
      'Album Artwork' => 
      array (
        0 => 'Illustration de l\'album',
      ),
      'Rename' => 
      array (
        0 => 'Renommer',
      ),
      'Select' => 
      array (
        0 => 'Sélectionner',
      ),
      'Home' => 
      array (
        0 => 'Accueil',
      ),
      '%s of %s Used (%d Files)' => 
      array (
        0 => '%s de %s utilisé (%d fichiers)',
      ),
      'You can also upload files in bulk via FTP.' => 
      array (
        0 => 'Vous pouvez également télécharger des fichiers en vrac via FTP.',
      ),
      'View connection instructions' => 
      array (
        0 => 'Voir les instructions de connexion',
      ),
      'Drag files here to upload to this folder or ' => 
      array (
        0 => 'Glissez ici les fichier à téléverser dans ce dossier ou ',
      ),
      'Set Playlists' => 
      array (
        0 => 'Définir les playlists',
      ),
      'New Playlist' => 
      array (
        0 => 'Nouvelle playlist',
      ),
      'Save' => 
      array (
        0 => 'Sauvegarder',
      ),
      'Clear Playlists' => 
      array (
        0 => 'Effacer les playlists',
      ),
      'Move' => 
      array (
        0 => 'Déplacer',
      ),
      'New Folder' => 
      array (
        0 => 'Nouveau dossier',
      ),
      'Length' => 
      array (
        0 => 'Durée',
      ),
      'Modified' => 
      array (
        0 => 'Modifié',
      ),
      'New Directory' => 
      array (
        0 => 'Nouveau répertoire',
      ),
      'Directory Name' => 
      array (
        0 => 'Nom du répertoire',
      ),
      'Create Directory' => 
      array (
        0 => 'Créer le répertoire',
      ),
      'Move {{ selected_files }} File(s) to' => 
      array (
        0 => 'Déplacer le(s) fichier(s) {{ selected_files }} vers',
      ),
      'Back' => 
      array (
        0 => 'Retour',
      ),
      'FTP Connection Information' => 
      array (
        0 => 'Informations de connexion FTP',
      ),
      'Server' => 
      array (
        0 => 'Serveur',
      ),
      'You may need to connect directly via your IP address, which is <code>%s</code>.' => 
      array (
        0 => 'Vous devez peut-être vous connecter directement via votre adresse IP, qui est <code>%s</code>.',
      ),
      'Port' => 
      array (
        0 => 'Port',
      ),
      'Protocol' => 
      array (
        0 => 'Protocole',
      ),
      'FTP with Explicit TLS (FTPS)' => 
      array (
        0 => 'FTP avec TLS explicite (FTPS)',
      ),
      'Unencrypted FTP is also allowed, but not recommended.' => 
      array (
        0 => 'Le FTP non chiffré est également autorisé, mais non recommandé.',
      ),
      'Your AzuraCast E-mail Address' => 
      array (
        0 => 'Votre adresse e-mail AzuraCast',
      ),
      'Your AzuraCast Password' => 
      array (
        0 => 'Votre mot de passe AzuraCast',
      ),
      'Available Logs' => 
      array (
        0 => 'Logs disponibles',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => 'Les points de montage sont la façon dont les auditeurs se connectent et écoutent votre station. Chaque point de montage peut avoir un format ou une qualité audio différente. En utilisant des points de montage, vous pouvez configurer un flux de haute qualité pour les auditeurs à large bande et un flux mobile pour les utilisateurs de téléphone.',
      ),
      'Mount Point' => 
      array (
        0 => 'Point de montage',
      ),
      'Delete mount point "%s"?' => 
      array (
        0 => 'Supprimer le point de montage "%s"?',
      ),
      'Default Mount' => 
      array (
        0 => 'Point de montage par défaut',
      ),
      'All Playlists' => 
      array (
        0 => 'Toutes les playlists',
      ),
      'Schedule View' => 
      array (
        0 => 'Calendrier',
      ),
      '# Songs' => 
      array (
        0 => '# Titres',
      ),
      'Delete playlist "%s"?' => 
      array (
        0 => 'Supprimer la playlist "%s" ?',
      ),
      'More' => 
      array (
        0 => 'Plus',
      ),
      'Disable' => 
      array (
        0 => 'Désactiver',
      ),
      'Enable' => 
      array (
        0 => 'Activer',
      ),
      'Reorder' => 
      array (
        0 => 'Réorganiser',
      ),
      'Export %s' => 
      array (
        0 => 'Exporter %s',
      ),
      'Song-based' => 
      array (
        0 => 'Sur la base de chansons',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Mode Jingle',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Auto-assigné',
      ),
      'Weight' => 
      array (
        0 => 'Poids',
      ),
      'Plays at %s' => 
      array (
        0 => 'Diffuse à %s',
      ),
      'Plays between %s and %s' => 
      array (
        0 => 'Joue entre %s et %s',
      ),
      'Once per %d Songs' => 
      array (
        0 => 'Une fois chaque %d Titres',
      ),
      'Once per %d Minutes' => 
      array (
        0 => 'Une fois chaque %d minutes',
      ),
      'Once per Hour (at :%02d)' => 
      array (
        0 => 'Une fois par heure (À : %02d)',
      ),
      'Custom' => 
      array (
        0 => 'Personnalisé',
      ),
      'Reorder Playlist' => 
      array (
        0 => 'Réorganiser la playlist',
      ),
      'Reorder Playlist: %s' => 
      array (
        0 => 'Réorganiser la playlist : %s',
      ),
      'Down' => 
      array (
        0 => 'En bas',
      ),
      'Up' => 
      array (
        0 => 'Haut',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Station de diffusion désactivée',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Votre station n\'est actuellement pas activée pour la diffusion. Vous pouvez toujours gérer les médias, les listes de lecture et les autres paramètres de station. Pour réactiver la diffusion, <a href="%s">modifier le profil de votre station</a>.',
      ),
      'Running' => 
      array (
        0 => 'Lancé',
      ),
      'Not Running' => 
      array (
        0 => 'Arrêté',
      ),
      'LiquidSoap is currently shuffling from <b>%d uploaded songs</b> in <b>%d playlists</b>.' => 
      array (
        0 => 'LiquidSoap joue actuellement <b>%d titres</b> dans <b>%d playlists</b>.',
      ),
      'Restart' => 
      array (
        0 => 'Redémarrer',
      ),
      'Start' => 
      array (
        0 => 'Démarrer',
      ),
      'Stop' => 
      array (
        0 => 'Arrêter',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ désactivé',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ a été désactivé pour cette station. Aucun musique ne se jouera automatiquement lorsqu’une source n’est pas en direct.',
      ),
      'Administration URL' => 
      array (
        0 => 'URL de l\'administration',
      ),
      'Administrator Password' => 
      array (
        0 => 'Mot de passe de l\'administrateur',
      ),
      'Source Password' => 
      array (
        0 => 'Mot de passe de la source',
      ),
      'Relay Password' => 
      array (
        0 => 'Mot de passe du relais',
      ),
      'On the Air' => 
      array (
        0 => 'À l\'antenne',
      ),
      'Listener' => 
      array (
        0 => 'Auditeur',
      ),
      'Unique' => 
      array (
        0 => 'Unique',
      ),
      'Playing Next' => 
      array (
        0 => 'À suivre',
      ),
      'Skip Song' => 
      array (
        0 => 'Passer ce titre',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Déconnecter le streamer',
      ),
      'Public Pages' => 
      array (
        0 => 'Page publique',
      ),
      'Player Embed Code' => 
      array (
        0 => 'Code du lecteur embarqué',
      ),
      'Request Embed Code' => 
      array (
        0 => 'Demande de code intégré',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Désactiver les pages publiques ?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Activer les pages publiques ?',
      ),
      'View' => 
      array (
        0 => 'Afficher',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Désactiver les demandes de musique ?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Activer les demandes de musique ?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Streamers/DJs',
      ),
      'Disable streamers?' => 
      array (
        0 => 'Désactiver les streamers ?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'Activer les streamers ?',
      ),
      'Streams' => 
      array (
        0 => 'Flux',
      ),
      'Local Streams' => 
      array (
        0 => 'Flux locaux',
      ),
      'Download PLS' => 
      array (
        0 => 'Télécharger le PLS',
      ),
      'Download M3U' => 
      array (
        0 => 'Télécharger M3U',
      ),
      'Listener Request' => 
      array (
        0 => 'Demande des auditeurs',
      ),
      'Playlist:' => 
      array (
        0 => 'Playlist :',
      ),
      'Delete queue item?' => 
      array (
        0 => 'Supprimer un élément de la file d\'attente ?',
      ),
      'Cued On' => 
      array (
        0 => 'En cours d\'exécution',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => 'Les relais distants vous permettent de travailler avec des logiciels de diffusion en dehors de ce serveur. Tout relais que vous incluez ici sera inclus dans les statistiques de votre station. Vous pouvez également diffuser depuis ce serveur vers des relais distants.',
      ),
      'Remote Relay' => 
      array (
        0 => 'Relais distant',
      ),
      'Delete remote relay "%s"?' => 
      array (
        0 => 'Supprimer le relais à distance "%s" ?',
      ),
      'Song Duplicates' => 
      array (
        0 => 'Titres en doublon',
      ),
      'No duplicates were found. Nice work!' => 
      array (
        0 => 'Aucun doublon n’a été trouvé. Beau travail !',
      ),
      'Title / File Path' => 
      array (
        0 => 'Titre / Chemin d’accès',
      ),
      'Live Listeners' => 
      array (
        0 => 'Auditeurs en direct',
      ),
      'There are too many data points to map!' => 
      array (
        0 => 'Il y a trop de points de données à cartographier !',
      ),
      'Download CSV' => 
      array (
        0 => 'Télécharger le CSV',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Auditeurs uniques',
      ),
      'for selected period' => 
      array (
        0 => 'pour la période sélectionnée',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Heures d\'écoute totales',
      ),
      'IP' => 
      array (
        0 => 'IP',
      ),
      'Time (sec)' => 
      array (
        0 => 'Durée (sec)',
      ),
      'User Agent' => 
      array (
        0 => 'User-Agent',
      ),
      'Location' => 
      array (
        0 => 'Localité',
      ),
      'Mobile Device' => 
      array (
        0 => 'Appareil mobile',
      ),
      'Desktop Device' => 
      array (
        0 => 'Périphérique de bureau',
      ),
      'Unknown' => 
      array (
        0 => 'Inconnu',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Ce produit inclut les données GeoLite2 créées par MaxMind, disponibles auprès de %s.',
      ),
      'Hour' => 
      array (
        0 => 'Heure',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Meilleurs titres',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'dans les dernières 48 heures',
      ),
      'Change' => 
      array (
        0 => 'Changer',
      ),
      'Song' => 
      array (
        0 => 'Titre',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Pires titres',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Titres les plus joués',
      ),
      'in the last month' => 
      array (
        0 => 'dans le dernier mois',
      ),
      'Plays' => 
      array (
        0 => 'Lectures',
      ),
      'Filename' => 
      array (
        0 => 'Nom de fichier',
      ),
      'Length Text' => 
      array (
        0 => 'Longueur du texte',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Playlist(s)',
      ),
      'Joins' => 
      array (
        0 => 'Arrivées',
      ),
      'Losses' => 
      array (
        0 => 'Départs',
      ),
      'Total' => 
      array (
        0 => 'Total',
      ),
      'Play %' => 
      array (
        0 => '% lectures',
      ),
      'Ratio' => 
      array (
        0 => 'Ratio',
      ),
      'Date Requested' => 
      array (
        0 => 'Date demandée',
      ),
      'Date Played' => 
      array (
        0 => 'Date de lecture',
      ),
      'Requester IP' => 
      array (
        0 => 'IP du demandeur',
      ),
      'Not Played' => 
      array (
        0 => 'Pas joué',
      ),
      'Report Not Available' => 
      array (
        0 => 'Rapport non disponible',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => 'Ce rapport n\'est pas disponible pour cette station, car l\'administrateur système a choisi de ne pas collecter d\'informations détaillées sur les auditeurs IP.',
      ),
      'Live Broadcast' => 
      array (
        0 => 'Diffusion en direct',
      ),
      'Please wait...' => 
      array (
        0 => 'Veuillez patienter...',
      ),
      'Station Time' => 
      array (
        0 => 'Heure de la station',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Les comptes pour les streamers sont actuellement désactivées pour cette station. Pour les activer, cliquez sur le bouton ci-dessous.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Activer le streaming',
      ),
      'Notes' => 
      array (
        0 => 'Notes',
      ),
      'Delete streamer "%s"?' => 
      array (
        0 => 'Supprimer le streamer "%s" ?',
      ),
      'Connection Information' => 
      array (
        0 => 'Informations de connexion',
      ),
      'IceCast Clients' => 
      array (
        0 => 'Clients IceCast',
      ),
      'Mount Name' => 
      array (
        0 => 'Point de montage',
      ),
      'ShoutCast v1 Clients' => 
      array (
        0 => 'Clients ShoutCast v1',
      ),
      '%d (%d for some clients)' => 
      array (
        0 => '%d (%dpour certains clients)',
      ),
      '(DJ username and password separated by a colon)' => 
      array (
        0 => '(Nom du DJ et mot de passe séparés par des deux-points)',
      ),
      'Setup instructions for broadcasting software are available <a href="%s" target="_blank">on the AzuraCast Wiki</a>.' => 
      array (
        0 => 'Des instructions pour la configuration de logiciels de diffusion sont disponibles <a href="%s" target="_blank">sur le Wiki d\'AzuraCast</a>.',
      ),
      'Select the type of web hook to create.' => 
      array (
        0 => 'Sélectionnez le type de Webhook à créer.',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => 'Les Webhooks vous permettent de vous connecter à des services Web externes et de diffuser les modifications apportées à votre station sur ces derniers.',
      ),
      'Type' => 
      array (
        0 => 'Type',
      ),
      'Triggers' => 
      array (
        0 => 'Déclencheurs',
      ),
      'Trigger the web hook manually and view the raw response.' => 
      array (
        0 => 'Déclenchez le Webhook manuellement et visualisez la réponse brute.',
      ),
      'Test' => 
      array (
        0 => 'Tester',
      ),
      'Delete web hook "%s"?' => 
      array (
        0 => 'Supprimer le Webhook "%s" ?',
      ),
      'The page you requested was not found.' => 
      array (
        0 => 'La page que vous avez demandée n\'a pas été trouvée.',
      ),
      'Select...' => 
      array (
        0 => 'Sélectionner...',
      ),
      'No results found!' => 
      array (
        0 => 'Aucun résultat trouvé!',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => 'Des erreurs ont été rencontrées lors de l\'enregistrement des modifications :',
      ),
      'General' => 
      array (
        0 => 'Général',
      ),
    ),
  ),
);