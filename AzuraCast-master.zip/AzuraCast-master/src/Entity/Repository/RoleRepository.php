<?php
namespace App\Entity\Repository;

use Azura\Doctrine\Repository;

class RoleRepository extends Repository
{

}