<?php
namespace App\Exception;

use Azura\Exception;

class SupervisorException extends Exception
{
}
