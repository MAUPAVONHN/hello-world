<?php
namespace App\Exception\Supervisor;

use App\Exception\SupervisorException;

class BadNameException extends SupervisorException
{
}
