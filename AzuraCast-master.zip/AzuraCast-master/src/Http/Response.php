<?php
namespace App\Http;

class Response extends \Azura\Http\Response
{
    /**
     * Empty placeholder class to hold possible future helper methods.
     */
}
